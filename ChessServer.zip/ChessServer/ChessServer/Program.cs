﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using Dapper;
using System.Data.SqlClient;
namespace ChessServer
{
    internal class Program
    {
        static TcpListener server = new TcpListener(IPAddress.Any, 8888);
        static string path = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Players;Integrated Security=True;Connect Timeout=30;";
        static List<UserClientServer> PlayersBlack=new List<UserClientServer>();
        static List<UserClientServer> PlayersWhite = new List<UserClientServer>();
        static bool IsWhite=true;
        public enum Commands
        {
            AddUser,
            Test,
            LogIn,
            Update,
            GetAllPlayers,
            GoToGame
        }
        static async Task Main(string[] args)
        {
            server.Start();
            while (true)
            {
                await Task.Yield();
                var client =await server.AcceptTcpClientAsync();
                UserClientServer user = new UserClientServer(client);
                Console.WriteLine("ClientConnected");
                _=Task.Run(() => GetCommand(user));
            }
        }
        static async Task GetCommand(UserClientServer user)
        {
       
            while (user.MyClient.Connected)
            {
                await Task.Yield();


                try
                {

                    if (!user.IsGameRun)
                    {
                        var read = await ReadNetworkStreamToStringAsync(user.stream);
                        Console.WriteLine(read);
                        var JsonParsed = JsonSerializer.Deserialize<ParsedJsonUser>(read);
                        switch (Convert.ToInt32(Enum.Parse(typeof(Commands), JsonParsed.RequstAndAnswer)))
                        {
                            case 0:

                                await Register(await AddPlayer(JsonParsed), JsonParsed, user);
                                break;
                            case 1:
                                Console.WriteLine("Test");
                                await SendAnswer(JsonParsed, user.stream);
                                break;
                            case 2:
                                await Register(await LogIn(JsonParsed), JsonParsed, user);
                                break;
                            case 3:
                                Console.WriteLine("Update");
                                await Register(await Update(JsonParsed, user), JsonParsed, user);
                                break;
                            case 4:
                                await JsonSerializer.SerializeAsync(user.stream, await GetAllPlayers());
                                break;
                            case 5:
                                Console.WriteLine("GoGame");
                                await AddPkayers(user);
                                break;

                        }
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(user.Name);
                    user.stream.Close();
                    user.stream.Dispose();
                    user.MyClient.Close();
                    user.MyClient.Dispose();
                    break;
                }
            }
        }
        static async Task<bool> AddPkayers(UserClientServer user)
        {
            Console.WriteLine("White " + PlayersWhite.Count + " BLack " + PlayersBlack.Count);
            if (IsWhite)
            {
                PlayersWhite.Add(user);       
            }
            else
            {
                PlayersBlack.Add(user);
                IsWhite = !IsWhite;
                while (user.IsGameRun)
                {
                    await Task.Yield();
                }
                return true;
            }
            IsWhite = !IsWhite;

            while (true)
            {
                await Task.Yield();
                
                if (PlayersBlack.Count == 0)
                {
                    continue;
                }
                else 
                {
                    var unfriend= PlayersBlack[0];
                    PlayersBlack.Remove(unfriend);
                    PlayersWhite.Remove(user);
                    await SendAnswer(new ParsedJsonUser()
                    {
                        Name = unfriend.Name,
                        Password = "White",
                        LoseCount=unfriend.LoseCount,
                        WinCount=unfriend.WinCount
                    },user.stream);
                    await SendAnswer(new ParsedJsonUser()
                    {
                        Name = user.Name,
                        Password = "Black",
                        LoseCount=user.LoseCount,
                        WinCount=user.WinCount
                    }, unfriend.stream);
                    return await GameRun(user, unfriend);
                    
                }

            }
     

        }
        static async Task<bool> GameRun(UserClientServer white,UserClientServer black)
        {

            var PlayerFirstMove = white;
            var PlayerSecondMove = black;
            while (true)
            {
                await Task.Yield();
                
                    try
                    {
        
                        await Task.Yield();
                        Console.WriteLine("rEAD");
                        var read =await ReadNetworkStreamToStringAsync(PlayerFirstMove.stream);
                        Console.WriteLine(read);
                        var WhiteMove= JsonSerializer.Deserialize<ParsedPlayerMove>(read.Substring(0,read.LastIndexOf('}')+1));
                        var buffer= Encoding.UTF8.GetBytes(read);
                       
                        Console.WriteLine("Write");
                        await PlayerSecondMove.stream.WriteAsync(buffer, 0, buffer.Length);
                        var t =  PlayerFirstMove;
                        PlayerFirstMove = PlayerSecondMove;
                        PlayerSecondMove = t;

                        if (WhiteMove.message.Contains("Win"))
                        {
                            return true;
                        }



                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        black.IsGameRun=false;
                        return false;
                    }
                
            }
        }
        static async Task<IEnumerable<UserDb>> GetAllPlayers()
        {
            using (SqlConnection connection = new SqlConnection(path))
            {
               return await connection.QueryAsync<UserDb>("Select [Name], [LoseCount],[WinCount] From Players");
            }
        }
        static async Task Register( bool executed,ParsedJsonUser parsedJson,UserClientServer user)
        {
            Console.WriteLine("SendAnswer");
            parsedJson.CommandExecuted = executed;
            if (parsedJson.CommandExecuted)
            {
                user.Name = parsedJson.Name;
                user.Password = parsedJson.Password;
            }
            await SendAnswer(parsedJson, user.stream);
        } 
        static async Task<bool> AddPlayer(ParsedJsonUser user)
        {
            using (SqlConnection connection = new SqlConnection(path))
            {
                if (await connection.QueryFirstOrDefaultAsync($"Select * from Players WHERE [Name]='{user.Name}'") != null)
                {
                    return false;
                }
              
                await connection.ExecuteAsync($"INSERT INTO Players ([Name],[Password]) values('{user.Name}','{user.Password}') ");
                return true;
                
            }
        }
        static async Task<bool> Update(ParsedJsonUser user,UserClientServer userClient1)
        {
            using (SqlConnection connection = new SqlConnection(path))
            {
                if (await connection.QueryFirstOrDefaultAsync($"Select * from Players WHERE [Name]='{userClient1.Name}'") == null)
                {
                    return false;
                }
                Console.WriteLine("UpdateStart");
                await connection.ExecuteAsync($"UPDATE Players set [Name]='{user.Name}' , [Password]='{user.Password}' where [Name]='{userClient1.Name}'");
                Console.WriteLine("UpdateEnd");
                return true;
            }
        }
        static async Task<bool> LogIn(ParsedJsonUser user)
        {
            using (SqlConnection connection = new SqlConnection(path))
            {
                return await connection.QueryFirstOrDefaultAsync($"Select * from Players WHERE [Name]='{user.Name}' and [Password]='{user.Password}'") != null;
            }
        }
      
        static async Task SendAnswer(ParsedJsonUser parsedJsonUser,NetworkStream stream)
        {
            parsedJsonUser.RequstAndAnswer = "IsAnswer";
            var str= JsonSerializer.Serialize(parsedJsonUser);
            Console.WriteLine(str);
            byte[] buffer = Encoding.UTF8.GetBytes(str);
            await stream.WriteAsync(buffer, 0, buffer.Length);
        }
        static async Task<string> ReadNetworkStreamToStringAsync(NetworkStream stream)
        {
            var buffer = new byte[1024];
            StringBuilder stringBuilder = new StringBuilder();
            int count;
            do
            {
                count = await stream.ReadAsync(buffer, 0, buffer.Length);
                stringBuilder.Append(Encoding.UTF8.GetString(buffer), 0, count);
                if (count < 1024)
                {
                    return stringBuilder.ToString();
                }
            } while (count > 0);
            return stringBuilder.ToString();
        }
    }
}
public class UserClientServer
{
    public string Name;
    public string Password;
    public int WinCount;
    public int LoseCount;
    public TcpClient MyClient;
    public NetworkStream stream;
    public bool IsGameRun = false;
    public UserClientServer(TcpClient client)
    {
        MyClient = client;
        stream = client.GetStream();
    }
}
public class ParsedPlayerMove
{
    public int x1 { get; set; }
    public int y1 { get; set; }
    public int x2 { get; set; }
    public int y2 { get; set; }
    public string message { get; set; }
}
public class UserDb
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Password { get; set; }
    public int WinCount { get; set; }
    public int LoseCount { get; set; }
} 
