﻿if  DB_ID('Players') IS NULL
	CREATE DATABASe Players
go
use Players

CREATE TABLE Players(
Id int  Primary Key IDENTITY(1,1),
[Name] varchar(max)  NOT NULL,
[Password] varchar(max) NOT NULL,
[WinCount] int,
[LoseCount] int,
)
	

