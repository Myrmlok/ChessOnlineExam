﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Text.Json;
using MVMM;
namespace Chess
{

    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static ViewModal viewModal;
        static WorkToServer WorkServer;
        string PlayerName;
        string PlayerPassword;
        int LoseCount;
        int WinCount;
        bool PlayerISWhite;
        bool ISYourMove = true;

        public MainWindow()
        {
            
            InitializeComponent();
            
            
            WorkServer = new WorkToServer();
            
            if (!WorkServer.Connection())
            {
                MessageBox.Show("Не удалось подключиться к серверу");
                Close();
            }
            viewModal = new ViewModal();
            DataContext = viewModal;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Button button = new Button();
                    Grid.SetRow(button, i);
                    Grid.SetColumn(button, j);
                    button.Click += Button_Click_2;
                    if (j % 2 == i % 2)
                    {
                        button.Background = Brushes.White;
                    }
                    else
                    {
                        button.Background = Brushes.Firebrick;
                    }
                    grid.Children.Add(button);
                }
            }
            for (int i = 0; i < viewModal.ChessWhite.FiguresMany.Count; i++)
            {
                Button button = new Button();
                button.DataContext = viewModal.ChessWhite.FiguresMany[i];
                Grid.SetColumn(button, viewModal.ChessWhite.FiguresMany[i].X);
                Grid.SetRow(button, viewModal.ChessWhite.FiguresMany[i].Y);
                button.Click += Button_Click_1;
                button.Background = new ImageBrush(new BitmapImage(new Uri(viewModal.ChessWhite.FiguresMany[i].SourceImage)));
                if (viewModal.ChessWhite.FiguresMany[i].IsRook)
                {
                    if (viewModal.ChessWhite.FiguresMany[i].X == 0)
                    {
                        viewModal.ChessWhite.king.RookLeft = button;
                    }
                    if (viewModal.ChessWhite.FiguresMany[i].X == 7)
                    {
                        viewModal.ChessWhite.king.RookRight = button;
                    }
                }
                grid.Children.Add(button);
            }
            for (int i = 0; i < viewModal.ChessBlack.FiguresMany.Count; i++)
            {
                Button button = new Button();
                button.DataContext = viewModal.ChessBlack.FiguresMany[i];
                Grid.SetColumn(button, viewModal.ChessBlack.FiguresMany[i].X);
                Grid.SetRow(button, viewModal.ChessBlack.FiguresMany[i].Y);
                button.Click += Button_Click_1;
                button.Background = new ImageBrush(new BitmapImage(new Uri(viewModal.ChessBlack.FiguresMany[i].SourceImage)));
                if (viewModal.ChessBlack.FiguresMany[i].IsRook)
                {
                    if (viewModal.ChessBlack.FiguresMany[i].X == 0)
                    {
                        viewModal.ChessBlack.king.RookLeft = button;
                    }
                    if (viewModal.ChessBlack.FiguresMany[i].X == 7)
                    {
                        viewModal.ChessBlack.king.RookRight = button;
                    }
                }
                grid.Children.Add(button);
            }
            
        }
        
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            
            Button button = sender as Button;
            Figures figures = button.DataContext as Figures;
            if (viewModal.WhiteMove == figures.IsWhite && viewModal.WhiteMove==PlayerISWhite)
            {
                viewModal.button = button;
                viewModal.SelectedFigure = figures;
                viewModal.CanGo = figures.CanGo(viewModal.ChessWhite, viewModal.ChessBlack);
            }
            else
            {
                Button_Click_2(sender, e);
            }
        }

        private async void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            int x = Grid.GetColumn(button);
            int y = Grid.GetRow(button);
            Point point = new Point(x, y);

            if (viewModal.CanGo == null ? false : viewModal.CanGo.Contains(point))
            {
                viewModal.WhiteMove = !viewModal.WhiteMove;
                MoveCheck moveCheck = new MoveCheck()
                {
                    FigureMove = viewModal.SelectedFigure.SourceImage,
                    NameFoMove = viewModal.musAlf[x] + y.ToString()
                };
                SideChess sideChess;
                SideChess friend;
                List<Point> unfreind = new List<Point>();
                if (viewModal.SelectedFigure.IsWhite)
                {
                    unfreind = viewModal.ChessBlack.GetPoints();
                    sideChess = viewModal.ChessBlack;
                    friend = viewModal.ChessWhite;
                }
                else
                {
                    unfreind = viewModal.ChessWhite.GetPoints();
                    sideChess = viewModal.ChessWhite;
                    friend = viewModal.ChessBlack;
                }
                if (unfreind != null)
                {
                    
                    if (unfreind.Contains(point))
                    {
                       
                        int index = unfreind.IndexOf(point);
                        moveCheck.GoTo = sideChess.FiguresMany[index].SourceImage;
                        viewModal.moveChecks.Add(moveCheck);
                        sideChess.FiguresMany[index].X = -1;
                        sideChess.FiguresMany[index].Y = -1;
                        grid.Children.Remove(button);
                        
                        if (sideChess.FiguresMany[index].IsKing)
                        {
                            if (ISYourMove)
                            {
                                await WorkServer.SendPlayerMoveToServer(new ParsedPlayerMove()
                                {
                                    message = "IsMoveWin",
                                    x1 = viewModal.SelectedFigure.X,
                                    y1 = viewModal.SelectedFigure.X,
                                    x2 = x,
                                    y2 = y
                                });
                            }
                            viewModal.SelectedFigure.X = x;
                            viewModal.SelectedFigure.Y = y;
                            Grid.SetColumn(viewModal.button, x);
                            Grid.SetRow(viewModal.button, y);
                            if (sideChess.FiguresMany[index].IsWhite)
                            {
                                MessageBox.Show("Black wins");
                            }
                            else
                            {
                                MessageBox.Show("White wins");
                            }
                            Close();
                        }
                    }
                }
                if (ISYourMove)
                {
                    var move = new ParsedPlayerMove()
                    {
                        message = "IsMove",
                        x1 = viewModal.SelectedFigure.X,
                        y1 = viewModal.SelectedFigure.Y,
                        x2 = x,
                        y2 = y
                    };
                    MessageBox.Show(JsonSerializer.Serialize<ParsedPlayerMove>(move));
                    await WorkServer.SendPlayerMoveToServer(move);
                }
                if (moveCheck.GoTo == "")
                {
                    string GoTo = "";
                    if (x % 2 == y % 2)
                    {
                        GoTo = $@"{Directory.GetCurrentDirectory()}\img\White.png";
                    }
                    else
                    {
                        GoTo = $@"{Directory.GetCurrentDirectory()}\img\BLack.png";
                    }
                    moveCheck.GoTo = GoTo;
                    viewModal.moveChecks.Add(moveCheck);
                }
                
                viewModal.SelectedFigure.X = x;
                viewModal.SelectedFigure.Y = y;
                Grid.SetColumn(viewModal.button, x);
                Grid.SetRow(viewModal.button, y);
               
                if (viewModal.SelectedFigure.IsKing&& viewModal.SelectedFigure.FirstMove)
                {
                    King king = viewModal.SelectedFigure as King;
                    if (point == king.RookLeftMove&&king.RookLeft!=null)
                    {
                        Rook rook= king.RookLeft.DataContext as Rook;
                        int index= friend.FiguresMany.IndexOf(rook);
                        friend.FiguresMany[index].X = x + 1;
                        Grid.SetColumn(king.RookLeft, friend.FiguresMany[index].X);
                    }
                    if (point == king.RookRightMove && king.RookRight  != null)
                    {
                        Rook rook = king.RookRight.DataContext as Rook;
                        int index = friend.FiguresMany.IndexOf(rook);
                        friend.FiguresMany[index].X = x - 1;
                        Grid.SetColumn(king.RookRight, friend.FiguresMany[index].X);
                    }
                }
                
                
                if (viewModal.SelectedFigure.IsPawn)
                {
                    if (viewModal.SelectedFigure.Y == 7 || viewModal.SelectedFigure.Y == 0)
                    {
                        string src = "";
                        if (viewModal.SelectedFigure.IsWhite)
                        {
                            src = "White";
                        }
                        else
                        {
                            src = "Black";
                        }
                        int _x = viewModal.SelectedFigure.X;
                        int _y = viewModal.SelectedFigure.Y;
                        bool isWhite = viewModal.SelectedFigure.IsWhite;
                        int index = friend.FiguresMany.IndexOf(viewModal.SelectedFigure);
                        friend.FiguresMany[index]= new Queen() { X = _x, Y = _y,IsWhite= isWhite, SourceImage = $@"{Directory.GetCurrentDirectory()}\img\{"Queen" + src + ".png"}" };
                        viewModal.button.Background = new ImageBrush(new BitmapImage(new Uri(friend.FiguresMany[index].SourceImage)));
                        viewModal.button.DataContext = friend.FiguresMany[index];
                        viewModal.SelectedFigure.FirstMove = false;

                    }
                }
                var Move=await WorkServer.GetPlayerMove();
                UnfriendMove(Move);

            }
        }
        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string str = button.DataContext as string;
            string Login="";
            string Password="";
            string RepeatPassword="";
            WorkToServer.Commands commands=WorkToServer.Commands.Test;
            if (str == "Login")
            {
                if (RegisterCardTop.Text!="Login")
                {
                    RegisterCardTop.Text = "Login";
                    (LoginCardData.Children[2] as TextBox).Visibility = Visibility.Hidden;
                    Repaet.Visibility = Visibility.Hidden;
                    return;
                }
                Login = (LoginCardData.Children[0] as TextBox).Text;
                Password = (LoginCardData.Children[1] as TextBox).Text;
                commands = WorkToServer.Commands.LogIn;
                
            }
            else
            {
                if (RegisterCardTop.Text != "Register")
                {
                    RegisterCardTop.Text = "Register";
                    (LoginCardData.Children[2] as TextBox).Visibility = Visibility.Visible;
                    Repaet.Visibility = Visibility.Visible;
                    return;
                };
                Login = (LoginCardData.Children[0] as TextBox).Text;
                Password = (LoginCardData.Children[1] as TextBox).Text;
                RepeatPassword = (LoginCardData.Children[2] as TextBox).Text;
                commands = WorkToServer.Commands.AddUser;
            }
            if (Login.Trim()=="" || Password.Trim() == "")
            {
                MessageBox.Show("Поля обязательны для заполнения");
                return;
            }
            if(Password != RepeatPassword && RegisterCardTop.Text == "Register")
            {
                MessageBox.Show("Пароли не совпадают");
                return;
            }
            WorkServer.user = new ParsedJsonUser()
            {
                Name = Login,
                Password = Password,
              
            };
            await  WorkServer.SendToServer(commands);
            var Answer =await WorkServer.GetAnswer();
            if (Answer.CommandExecuted)
            {
                PlayerPassword = viewModal.Password = Password;
                PlayerName= viewModal.Name = Login;
                viewModal.Win_Lose = $"{Answer.WinCount}" + '/' + $"{Answer.LoseCount}";
                WinCount = Answer.WinCount;
                LoseCount = Answer.LoseCount;
                LoginCard.Visibility = Visibility.Hidden;
                MainMenu.Visibility = Visibility.Visible;
            }
        }

        private void Button_ClickProfile_3(object sender, RoutedEventArgs e)
        {
            MainMenu.Visibility = Visibility.Hidden;
            ProfileCard.Visibility = Visibility.Visible;
        }

        private async void Update_Click(object sender, RoutedEventArgs e)
        {
            WorkServer.user = new ParsedJsonUser()
            {
                Name = viewModal.Name,
                Password = viewModal.Password
            };
            await WorkServer.SendToServer(WorkToServer.Commands.Update);
            var answer =await WorkServer.GetAnswer();
            if (answer.CommandExecuted)
            {
                MessageBox.Show("Ok");
                PlayerName = answer.Name;
                PlayerPassword = answer.Password;
            }
        }

        private void CloseProfile_Click(object sender, RoutedEventArgs e)
        {
            ProfileCard.Visibility = Visibility.Hidden;
            MainMenu.Visibility = Visibility.Visible;
            viewModal.Name = PlayerName;
            viewModal.Password = PlayerPassword;
        }

        private async void StartGame_Click(object sender, RoutedEventArgs e)
        {
            await WorkServer.SendToServer(WorkToServer.Commands.GoToGame);
            var MyAnswer=await WorkServer.GetAnswer();
            if (MyAnswer.Password == "White")
            {
                (PlayerWhite.Children[0] as TextBlock).Text = PlayerName;
                (PlayerWhite.Children[1] as TextBlock).Text = viewModal.Win_Lose;
                (PlayerBlack.Children[0] as TextBlock).Text = MyAnswer.Name;
                (PlayerBlack.Children[1] as TextBlock).Text =MyAnswer.WinCount.ToString()+"/"+MyAnswer.LoseCount.ToString();
                PlayerISWhite = true;
            }
            else
            {
                (PlayerBlack.Children[0] as TextBlock).Text = PlayerName;
                (PlayerBlack.Children[1] as TextBlock).Text = viewModal.Win_Lose;
                (PlayerWhite.Children[0] as TextBlock).Text = MyAnswer.Name;
                (PlayerWhite.Children[1] as TextBlock).Text = MyAnswer.WinCount.ToString() + "/" + MyAnswer.LoseCount.ToString();
                PlayerISWhite = false;
            }
            
            MainMenu.Visibility = Visibility.Hidden;
            BodyGame.Visibility = Visibility.Visible;
            if (!PlayerISWhite)
            {
                var Move = await WorkServer.GetPlayerMove();
                UnfriendMove(Move);
            }
        }
        void UnfriendMove(ParsedPlayerMove move)
        {
            Button figure = null;
            Button moveTo = null;
         
            foreach(var e in grid.Children)
            {

                Button button = e as Button;
                if (e != null)
                {
                    if (Grid.GetColumn(button) == move.x1 && Grid.GetRow(button) == move.y1)
                    {
                        figure = button;
          
                        
                    }
                    if (Grid.GetColumn(button) == move.x2 && Grid.GetRow(button) == move.x2)
                    {
                        moveTo = button;
                        
                        
                    }
                }
            }
            ISYourMove = false;
            PlayerISWhite = !PlayerISWhite;
            Button_Click_1(figure, new RoutedEventArgs());
            Button_Click_2(moveTo, new RoutedEventArgs());
            PlayerISWhite = !PlayerISWhite;
            ISYourMove = true;
       
        }
    }
    
}

